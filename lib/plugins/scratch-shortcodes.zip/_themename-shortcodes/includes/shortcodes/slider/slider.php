<?php

function scratch_slider($atts = [], $content = null, $tag = '') {
   extract(shortcode_atts([
      'autoplay' => false,
      'arrows' => false
   ], $atts, $tag));

   $o = '<div class="scratch-slider" data-slick=\'{"autoplay":' . ($autoplay ? 'true' : 'false') . ', "arrows": ' . ($arrows ? 'true' : 'false') . '}\'>';

   if(!is_null($content)) {
      $o .= do_shortcode($content);
   }

   $o .= '</div>';

   return $o;
}
add_shortcode('scratch_slider', 'scratch_slider');

function scratch_slide($atts = [], $content = null, $tag = '') {
   extract(shortcode_atts([
      'image' => null,
      'caption' => ''
   ], $atts, $tag));

   $o = '<div class="scratch-slide">';

   if($image) {
      $o .= wp_get_attachment_image($image, 'large');
   }
   if($caption) {
      $o .= '<div class="scratch-slide-caption">' . esc_html($caption) . '</div>';
   }

   $o .= '</div>';

   return $o;
}
add_shortcode('scratch_slide', 'scratch_slide');