import $ from 'jquery';

$(document).ready(() => {
   // $('.scratch-slider').slick();
});