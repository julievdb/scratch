<?php
/*
Plugin Name: Scratch Shortcodes
Plugin URI:
Description: Adding Shortcodes for Scratch
Version:     1.0.0
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: scratch-shortcodes
Domain Path: /languages
*/

if(!defined('WPINC')) {
   die;
}

function scratch_shortcodes_init() {
   include_once('includes/shortcodes/button/button.php');
   include_once('includes/shortcodes/slider/slider.php');
}

add_action('init', 'scratch_shortcodes_init');

include_once('includes/enqueue-assets.php');

?>